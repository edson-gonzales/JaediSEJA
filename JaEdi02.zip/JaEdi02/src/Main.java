
public class Main {
	public static void main(String []Args){
	Window window=new Window();
	window.setVisible(true);
	
	}
}
